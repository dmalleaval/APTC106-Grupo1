from django.apps import AppConfig


class FoodsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.food"
    verbose_name = "FoodPlease"
