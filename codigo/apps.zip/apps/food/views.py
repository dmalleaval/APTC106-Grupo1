from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .forms import LoginForm, FoodsForm
from .models import Categoria, Producto


def log_in(request):
    if request.user.is_authenticated:
        return redirect("food:home")

    form = LoginForm(request.POST or None)
    context = {"message": None, "form": form}

    if request.method == "POST" and form.is_valid():
        user = authenticate(request, **form.cleaned_data)

        if user is not None:
            if user.is_active:
                login(request, user)
                return redirect("food:home")

            context["message"] = "El usuario ha sido desactivado"
        else:
            context["message"] = "Usuario o contraseña incorrecta"

    return render(request, "foods/login.html", context)


@login_required
@require_POST
def log_out(request):
    logout(request)
    return redirect("food:log-in")


@login_required
def food_list(request):
    foods = Producto.objects.select_related("categoria").all()
    return render(request, "foods/index.html", {"foods": foods})


@login_required
def food_detail(request, pk):
    food = get_object_or_404(Producto.objects.select_related("categoria"), pk=pk)
    return render(request, "foods/detail.html", {"food": food})


@login_required
def food_create(request):
    form = FoodsForm(request.POST or None, request.FILES or None)
    if request.method == "POST" and form.is_valid():
        form.save()
        return redirect("food:home")
    return render(request, "foods/form.html", {"form": form})


@login_required
def food_update(request, pk):
    food = get_object_or_404(Producto, pk=pk)
    form = FoodsForm(request.POST or None, request.FILES or None, instance=food)
    if request.method == "POST" and form.is_valid():
        form.save()
        return redirect("food:home")
    return render(request, "foods/form.html", {"form": form})


@login_required
@require_POST
def food_delete(request, pk):
    food = get_object_or_404(Producto, pk=pk)
    food.delete()
    return redirect("food:home")


@login_required
def category_list(request):
    categories = Categoria.objects.all()
    return render(
        request,
        "foods/category/category_list.html",
        {"categories": categories},
    )
