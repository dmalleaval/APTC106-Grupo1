from django.contrib import admin
from .models import Categoria, Producto

# Register your models here.


@admin.register(Categoria, Producto)
class BaseAdminRegister(admin.ModelAdmin):
    pass
