from django.urls import include, path

from apps.food import views

app_name = "food"

foods_patterns = [
    path("inicio/", views.food_list, name="home"),
    path("crear/", views.food_create, name="foods-create"),
    path("<int:pk>/", views.food_detail, name="foods-detail"),
    path("<int:pk>/editar/", views.food_update, name="foods-edit"),
    path("<int:pk>/eliminar/", views.food_delete, name="foods-delete"),
]

urlpatterns = [
    path("", views.log_in, name="log-in"),
    path("log-out/", views.log_out, name="log-out"),
    path("categorias/", views.category_list, name="category-list"),
    path("comidas/", include(foods_patterns)),
]
